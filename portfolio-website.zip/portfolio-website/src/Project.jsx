import image1 from "./image1.jpg"

export default function Project()
{
    const projectSectionStyle = {
  width: '1440px',
  height: '1824px',
  padding: '60px 80px',
  backgroundColor: '#000000',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center', // Centers the content 
  gap: '40px',          // Space between the title and the project grid
  margin: '0 auto',     // Centers the 1440px section
  opacity: 1,
  boxSizing: 'border-box',
};
const projectContainerStyle = {
  width: '1280px',
  height: '1704px',
  paddingLeft: '32px',
  paddingRight: '32px',
  display: 'flex',
  flexDirection: 'column',
  gap: '20px', // Spacing between project rows/cards
  margin: '0 auto',
  opacity: 1,
  boxSizing: 'border-box',
};
const projectCardStyle = {
  width: '1216px',
  height: '516px',
  paddingTop: '20px',
  paddingBottom: '20px',
  display: 'flex',
  flexDirection: 'row', // Side-by-side: Image + Text
  alignItems: 'center',
  gap: '40px',          // Spacing between image and description
  opacity: 1,
  boxSizing: 'border-box',
  backgroundColor: 'transparent', // Usually sits on the black section background
};
const projectDetailsStyle = {
  width: '582px',
  height: '296px',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center', // Vertically centers text against the image
  gap: '24px',
  opacity: 1,
  boxSizing: 'border-box',
};
const readMoreStyle = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 400,
  fontStyle: 'normal',
  fontSize: '16px',
  lineHeight: '24px',
  letterSpacing: '0.02em',
  color: '#FFFFFF',          // High contrast text for the grey background
  backgroundColor: '#71717A', 
  padding: '8px 16px',       // Standard button padding
  borderRadius: '4px',       // Clean, subtle rounding
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  cursor: 'pointer',
  textDecoration: 'none',
  opacity: 1,
};
const projectImageAreaStyle = {
  width: '594px',
  height: '476px',
  borderRadius: '20px', // Optional: adds a modern, smooth finish
  overflow: 'hidden',
  backgroundColor: '#27272A', // Placeholder color while images load
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  opacity: 1,
  boxSizing: 'border-box',
};
const projectImageStyle = {
  width: '530px', // Rounded for cleaner CSS
  height: '397.73px',
  borderRadius: '18.76px',
  opacity: 1,
  // Combining your two box-shadows into a single CSS property:
  boxShadow: `
    0px 12px 42px -4px rgba(24, 39, 75, 0.12), 
    0px 8px 18px -6px rgba(24, 39, 75, 0.12)
  `,
  objectFit: 'cover',
  display: 'block',
  boxSizing: 'border-box',
};
const headingStyles = {
  width: '1216px',
  height: '96px',
  display: 'flex',
  flexDirection: 'column', // Stacks title and subtitle vertically
  justifyContent: 'center', // Centers content vertically within the 96px height
  alignItems: 'center',     // Centers content horizontally
  paddingTop: '20px',
  paddingBottom: '20px',
  gap: '16px',
  transform: 'rotate(0deg)',
  opacity: 1,
  boxSizing: 'border-box',
  margin: '0 auto'          // Keeps it centered within the 1280px container
};
const myTextStyles = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 400,
  fontStyle: 'normal',
  fontSize: '48px',
  lineHeight: '56px',
  letterSpacing: '-0.96px', // -2% of 48px
  marginRight: '15px',
  display: 'inline-block', // Keeps it on the same line as the next word
  opacity: 1,
  color:'white'
};
const skillsTextStyle = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 800,
  fontStyle: 'normal', // ExtraBold is defined by the 800 weight
  fontSize: '48px',
  lineHeight: '56px',
  letterSpacing: '-0.96px', // -2% of 48px
  margin: 0,
  display: 'inline-block',
  opacity: 1,
  color:'white'
};
return(
 <div style={projectSectionStyle}>
    <div style={headingStyles}>
  <h2 style={{ margin: 0 }}>
    <span style={myTextStyles}>My</span> {/* Added a space here */}
    <span style={skillsTextStyle}>Projects</span>
  </h2>
  </div>
    <div style={projectContainerStyle}>

        <div style={projectCardStyle}>
            <div style={projectImageAreaStyle}>
                <div style={projectImageStyle}>
                    <img src={image1} />
                </div>
            </div>
            <div style={projectDetailsStyle}>
                <span class={myTextStyles}>01</span>
                <div style={readMoreStyle}>
                    I'm Flora Sheen Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to specimen book.
                </div>
            </div>
        </div>

         <div style={projectCardStyle}>
            <div style={projectImageAreaStyle}>
                <div style={projectImageStyle}>
                    <img src={image1} />
                </div>
            </div>
            <div style={projectDetailsStyle}>
                <span class={myTextStyles}>01</span>
                <div style={readMoreStyle}>
                    I'm Flora Sheen Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to specimen book.
                </div>
            </div>
        </div>

         <div style={projectCardStyle}>
            <div style={projectImageAreaStyle}>
                <div style={projectImageStyle}>
                    <img src={image1} />
                </div>
            </div>
            <div style={projectDetailsStyle}>
                <span class={myTextStyles}>01</span>
                <div style={readMoreStyle}>
                    I'm Flora Sheen Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to specimen book.
                </div>
            </div>
        </div>
    </div>
 </div>
)
}