
export default function Experience()
{
    const headingStyles = {
  width: '1216px',
  height: '96px',
  display: 'flex',
  flexDirection: 'column', // Stacks title and subtitle vertically
  justifyContent: 'center', // Centers content vertically within the 96px height
  alignItems: 'center',     // Centers content horizontally
  paddingTop: '20px',
  paddingBottom: '20px',
  gap: '16px',
  transform: 'rotate(0deg)',
  opacity: 1,
  boxSizing: 'border-box',
  margin: '0 auto',          // Keeps it centered within the 1280px container
  background: '1px solid #71717A'
};
    const myTextStyles = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 400,
  fontStyle: 'normal',
  fontSize: '48px',
  lineHeight: '56px',
  letterSpacing: '-0.96px', // -2% of 48px
  marginRight: '15px',
  display: 'inline-block', // Keeps it on the same line as the next word
  opacity: 1,
  color:' #FFFFFF'
};
const skillsTextStyle = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 800,
  fontStyle: 'normal', // ExtraBold is defined by the 800 weight
  fontSize: '48px',
  lineHeight: '56px',
  letterSpacing: '-0.96px', // -2% of 48px
  margin: 0,
  display: 'inline-block',
  opacity: 1,
  color:' #FFFFFF'
};
const experienceContainerStyle = {
  width: '1216px',
  height: '720px',
  display: 'flex',
  flexDirection: 'column', // Stacks the job cards on top of each other
  alignItems: 'center',    // Centers the cards horizontally
  padding: '40px 24px',    // Top/Bottom 40px, Left/Right 24px
  gap: '32px',             // The space between each job card
  transform: 'rotate(0deg)',
  opacity: 1,
  boxSizing: 'border-box',
  margin: '0 auto',        // Centers the 1216px block in your 1440px section
  border: '1px solid #000000'
};
const experienceCardStyle = {
  width: '1168px',
  minHeight: '192px', // Use minHeight instead of height
  height: 'auto',      // Allows the card to expand
  display: 'flex',
  flexDirection: 'column', // CRITICAL: This stacks the row and the paragraph
  justifyContent: 'center',
  padding: '30px 24px',
  background:'border: 1px solid #71717A'
  // ... other styles
};
const experienceDescriptionStyle = {
  // Typography from your specs
  fontFamily: 'Sora, sans-serif',
  fontWeight: 400,
  fontSize: '16px',
  lineHeight: '24px',
  letterSpacing: '0.02em', // 2% converted to em
  color: '#71717A',        // A soft grey typical for body text
  
  // Layout
  width: '1120px',         // Matches the tagRow width for perfect alignment
  margin: '28px 0 0 0',    // This 28px margin matches your 'gap' from earlier
  textAlign: 'left',
  opacity: 1,
  color:'#D4D4D8'
};
const tagRowStyle = {
  width: '1120px',
  height: '32px',
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center', // Keeps the text perfectly aligned on the same horizontal line
  transform: 'rotate(0deg)',
  opacity: 1,
  boxSizing: 'border-box'
};
const jobTitleContainerStyle = {
  width: '1018px',
  height: '32px',
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',    // Keeps the logo and text vertically aligned
  justifyContent: 'flex-start', // Keeps everything pushed to the left
  gap: '30px',             // The specific spacing from your Figma
  transform: 'rotate(0deg)',
  opacity: 1,
  boxSizing: 'border-box'
};
const GoogleIcon = () => {
  const containerStyle = {
    width: '32px', // Standardized for your 32x32 jobTitleContainer
    height: '32px',
    position: 'relative',
    display: 'inline-block',
  };

  const vector1 = {
    width: '22.32px',
    height: '11.23px',
    position: 'absolute',
    top: '2px',
    left: '3.52px',
    backgroundColor: '#EB4335',
    clipPath: 'polygon(0% 0%, 100% 0%, 80% 100%, 20% 100%)', // Approximate G-top curve
    opacity: 1,
  };

  const vector2 = {
    width: '6.16px',
    height: '12.64px',
    position: 'absolute',
    top: '9.65px',
    left: '2px',
    backgroundColor: '#FBBC05',
    clipPath: 'polygon(0% 20%, 100% 0%, 100% 100%, 0% 80%)', // Approximate G-left curve
    opacity: 1,
  };

  const vector3 = {
    width: '22.22px',
    height: '11.23px',
    position: 'absolute',
    top: '18.77px',
    left: '3.52px',
    backgroundColor: '#34A853',
    clipPath: 'polygon(20% 0%, 80% 0%, 100% 100%, 0% 100%)', // Approximate G-bottom curve
    opacity: 1,
  };

  const vector4 = {
    width: '13.71px',
    height: '13.16px',
    position: 'absolute',
    top: '13.45px',
    left: '16.29px',
    backgroundColor: '#4285F4',
    clipPath: 'polygon(0% 0%, 100% 0%, 100% 50%, 0% 50%)', // Approximate G-bar
    opacity: 1,
  };

  return (
    <div style={containerStyle}>
      <div style={vector1}></div>
      <div style={vector2}></div>
      <div style={vector3}></div>
      <div style={vector4}></div>
    </div>
  );
};
const YoutubeIcon = () => {
  const containerStyle = {
    width: '32px',
    height: '32px',
    position: 'relative',
    display: 'inline-block',
  };

  const redBackgroundStyle = {
    width: '28px',
    height: '20px',
    position: 'absolute',
    top: '6px',
    left: '2px',
    backgroundColor: '#FC0D1B',
    borderRadius: '6px', // Standard YouTube curvature
    opacity: 1,
  };

  const whiteTriangleStyle = {
    width: '8px',
    height: '8px',
    position: 'absolute',
    top: '12px',
    left: '13px',
    backgroundColor: '#FFFFFF',
    // This turns the square into a right-pointing triangle
    clipPath: 'polygon(0% 0%, 0% 100%, 100% 50%)',
    opacity: 1,
  };

  return (
    <div style={containerStyle}>
      <div style={redBackgroundStyle}></div>
      <div style={whiteTriangleStyle}></div>
    </div>
  );
};
const AppleIcon = () => {
  const containerStyle = {
    width: '32px',
    height: '32px',
    position: 'relative',
    display: 'inline-block',
  };

  const backgroundStyle = {
    width: '28px',
    height: '28px', // Rounded from 27.999...
    position: 'absolute',
    top: '2px',
    left: '2px',
    backgroundColor: '#283544', // Dark Navy/Charcoal
    borderRadius: '6px',        // Matches the rounded aesthetic of the others
    opacity: 1,
  };

  const appleShapeStyle = {
    width: '14px',
    height: '16px',
    position: 'absolute',
    top: '7px',
    left: '9px',
    backgroundColor: '#FFFFFF',
    // Creating the "Apple" silhouette with a clip-path
    // This mimics the leaf at the top and the bitten body
    clipPath: 'polygon(50% 0%, 65% 20%, 100% 20%, 90% 50%, 100% 80%, 80% 100%, 50% 90%, 20% 100%, 0% 80%, 10% 50%, 0% 20%, 35% 20%)',
    opacity: 1,
  };

  return (
    <div style={containerStyle}>
      <div style={backgroundStyle}></div>
      <div style={appleShapeStyle}></div>
    </div>
  );
};
const dateBadgeStyle = {
  // Typography
  fontFamily: 'Sora, sans-serif',
  fontWeight: 600,
  fontSize: '16px',
  lineHeight: '20px',
  letterSpacing: '-0.02em', // -2% converted to em
  
  // Layout & Alignment
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  textAlign: 'center',
  
  // Visuals
  color: '#D4D4D8',
  padding: '6px 12px', // Adding padding to give the background some "room"
  borderRadius: '6px', // Matches your experience card radius
  opacity: 1,
  whiteSpace: 'nowrap'
};
 return(
    <div style={{backgroundColor:'black'}}>
    <div style={headingStyles}>
    <h2 style={{ margin: 0 }}>
    <span style={myTextStyles}>My</span> {/* Added a space here */}
    <span style={skillsTextStyle}>Experience</span>
    </h2>
    </div>
    <div style={experienceContainerStyle}>
        <div style={experienceCardStyle}>
            <div style={tagRowStyle}>
                <div style={jobTitleContainerStyle}>
                    <GoogleIcon /> 
  <span style={skillsTextStyle}>Software Engineer at Google</span>
                </div>
                <div style={dateBadgeStyle}>
            Nov 2019 - Present
           </div>
            </div>
        <p style={experienceDescriptionStyle}>As a Senior Software Engineer at Google, I played a pivotal role in developing innovative solutions for Google's core search algorithms. Collaborating with a dynamic team of engineers, I contributed to the enhancement of search accuracy and efficiency, optimizing user experiences for millions of users worldwide.</p>    
        </div>
        <div style={experienceCardStyle}>    
            <div style={tagRowStyle}>
                <div style={jobTitleContainerStyle}>
                    <YoutubeIcon /> 
  <span style={skillsTextStyle}>Software Engineer at Youtube</span>
                </div>
                <div style={dateBadgeStyle}>
            Nov 2019 - Present
           </div>
            </div>
            <p style={experienceDescriptionStyle}>At Youtube, I served as a  Software Engineer, focusing on the design and implementation of backend systems for the social media giant's dynamic platform. Working on projects that involved large-scale data processing and user engagement features, I leveraged my expertise to ensure seamless functionality and scalability.</p>
        </div>
        <div style={experienceCardStyle}>    
            <div style={tagRowStyle}>
                <div style={jobTitleContainerStyle}>
                    <AppleIcon /> 
  <span style={skillsTextStyle}>Junior Software Engineer at Apple</span>
                </div>
                <div style={dateBadgeStyle}>
            Nov 2019 - Present
           </div>
            </div>
            <p style={experienceDescriptionStyle}>
                During my tenure at Apple, I held the role of Software Architect, where I played a key role in shaping the architecture of mission-critical software projects. Responsible for designing scalable and efficient systems, I provided technical leadership to a cross-functional team.
            </p>
        </div>
    </div>
    </div>
 )
}