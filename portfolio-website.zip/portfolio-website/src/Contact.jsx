export default function Contact()
{
    const contactSectionStyle = {
  width: '1280px',
  height: '484px',
  margin: '0 auto',
  display: 'flex',
  flexDirection: 'row', // Aligning info and form side-by-side
  justifyContent: 'space-between',
  padding: '0 32px', // Left and right padding of 32px
  alignItems: 'center', // Centers the content vertically within the 484px height
  opacity: 1,
  boxSizing: 'border-box',
};
const Column1Style = {
  width: '608px',
  height: '484px',
  paddingTop: '20px',
  paddingBottom: '20px',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center', // Centers content vertically within the 484px
  gap: '40px',             // Space between the title, description, and social icons
  opacity: 1,
  boxSizing: 'border-box',
};
const inputAreaStyle = {
  width: '608px',
  height: '444px', // Slightly shorter than the 484px column to allow for alignment
  display: 'flex',
  flexDirection: 'column',
  gap: '20px',    // The specific spacing between inputs
  opacity: 1,
  boxSizing: 'border-box',
};
const Column2Style = {
  width: '608px',
  height: '484px',
  paddingTop: '20px',
  paddingBottom: '20px',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center', // Aligns the form vertically with Column 1
  opacity: 1,
  boxSizing: 'border-box',
};
const textAreaStyle = {
  width: '608px',
  height: '444px',
  display: 'flex',
  flexDirection: 'column',
  gap: '40px', // The specific spacing between your input groups/button
  opacity: 1,
  boxSizing: 'border-box',
};
const smallComponentsStyle = {
  width: '500px',
  height: '56px',
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  gap: '12px', // Space between icon and text, or label and input
  opacity: 1,
  boxSizing: 'border-box',
};
const inputTextFrameStyle = {
  width: '500px',
  height: '56px',
  padding: '16px 24px', // Top/Bottom 16, Left/Right 24
  borderRadius: '4px',
  border: '1.4px solid #000000',
  backgroundColor: '#FFFFFF', // Assuming white background
  fontFamily: 'Sora, sans-serif',
  fontSize: '16px',
  color: '#000000',
  outline: 'none', // Removes the default blue browser focus ring
  boxSizing: 'border-box',
  opacity: 1,
};
const largeComponentStyle = {
  width: '500px',
  height: '140px',
  display: 'flex',
  flexDirection: 'row', // Stacks label (if any) and textarea
  gap: '12px',
  opacity: 1,
  boxSizing: 'border-box',
  border: '1.4px solid #000000',
  borderRadius: '4px',
};
const messageFrameStyle = {
  width: '608px',
  height: '192px',
  display: 'flex',
  flexDirection: 'column',
  gap: '20px', // Spacing between the label/instruction and the textarea itself
  opacity: 1,
  boxSizing: 'border-box',
};
const informationFrameStyle = {
  width: '608px',
  height: '80px',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  gap: '16px',
  opacity: 1,
  boxSizing: 'border-box',
};
const bigFontBoxStyle = {
  width: '608px',
  height: '100px',
  display: 'flex',
  flexDirection: 'row',
  gap: '12px', // Space between the lines of text
  opacity: 1,
  boxSizing: 'border-box',
};
const developerStyles = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 800,
  fontStyle: 'normal',
  fontSize: '48px',
  lineHeight: '56px',
  letterSpacing: '-0.96px',
  width: '252px',
  height: '56px',
  display: 'flex',
//   justifyContent: 'center',
  alignItems: 'center',
  transform: 'rotate(0deg)',
  opacity: 1,
  boxSizing: 'border-box',
  
  // THIS MAKES THE TEXT HOLLOW AND GIVES IT A THICK BLACK OUTLINE:
  WebkitTextStroke: '2px #000000', // For most modern browsers
  textStroke: '2px #000000',       // Standard (if supported)
  color: 'transparent'              // Makes the inside of letters see-through
};
const florasheenStyles = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 800,
  fontStyle: 'normal', // 'ExtraBold' is defined by the 800 weight
  fontSize: '48px',
  lineHeight: '56px',
  letterSpacing: '-0.96px', // -2% of 48px
  margin: 0,
  display: 'inline-block', // Helps with spacing if it's next to "Hello I am"
  opacity: 1,
};
const paragraphStyle = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 400,
  fontStyle: 'normal', // "Regular" in CSS
  fontSize: '16px',
  lineHeight: '24px',
  letterSpacing: '0.02em', // 2% letter spacing
  color: '#71717A',        // The cool grey often used for body text in your project
  textAlign: 'left',
  margin: 0,
  opacity: 1,
};
const informationTextStyle = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 600,
  fontStyle: 'normal', // SemiBold
  fontSize: '28px',
  lineHeight: '32px',
  letterSpacing: '-0.02em', // Negative 2% for that sleek, professional look
  color: '#000000',
  textAlign: 'left',
  margin: 0,
  opacity: 1,
};
const buttonListStyle = {
  width: '493px',
  height: '56px',
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  gap: '24px', // Space between the button and social icons
  opacity: 1,
  boxSizing: 'border-box',
};
const iconFrameBase = {
  width: '56px',
  height: '56px',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  borderRadius: '4px',
  border: '3px solid #000000',
  boxSizing: 'border-box',
  cursor: 'pointer'
};
const iconSvgStyle = {
  width: '20px',
  height: '19.88px',
  display: 'block'
};
return(
<div style={contactSectionStyle}>
    <div style={Column1Style}>
        <div style={inputAreaStyle}>
            <div style={smallComponentsStyle}>
                <div style={inputTextFrameStyle}>
                    Your Name
                </div>
            </div>
            <div style={smallComponentsStyle}>
                <div style={inputTextFrameStyle}>
                    Email
                </div>
            </div>
            <div style={smallComponentsStyle}>
                <div style={inputTextFrameStyle}>
                    Your Website
                </div>
            </div>
            <div style={largeComponentStyle}>        
                   How Can I Help?
            </div>
        </div>
        <div style={{display:'flex'}}>
        <button className="resume-button" style={{width:'180px', height:'55px',marginRight:'10px'}}>Get Started</button>
        <div style={buttonListStyle}>
            <div style={{ display: 'flex', gap: '32px' }}>
  {/* 1. Facebook (Inverted) */}
  <div style={{ ...iconFrameBase, backgroundColor: '#000000' }}>
    <svg style={iconSvgStyle} viewBox="0 0 24 24">
      <path fill="white" d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c5.05-.5 9-4.76 9-9.95z"/>
    </svg>
  </div>

  {/* 2. Reddit */}
  <div style={iconFrameBase}>
    <svg style={iconSvgStyle} viewBox="0 0 24 24">
      <path fill="black" d="M24 11.5c0-1.38-1.12-2.5-2.5-2.5-.54 0-1.04.17-1.45.47C18.15 8.16 15.65 7.5 13 7.5l1.3-4 3.7.8c0 .8 1 1.5 2 1.5s2-1 2-2-1-2-2-2-2 1-2 2l-4-.9c-.2-.04-.4.1-.45.3L12 7.5c-2.65 0-5.15.66-7.05 1.97-.41-.3-.91-.47-1.45-.47-1.38 0-2.5 1.12-2.5 2.5 0 .95.53 1.77 1.32 2.2-.07.4-.12.8-.12 1.25 0 3.87 4.48 7 10 7s10-3.13 10-7c0-.45-.05-.85-.12-1.25.79-.43 1.32-1.25 1.32-2.2zM7.5 14.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm10.81 4.14c-1.32 1.32-3.83 1.41-5.31 1.41s-3.99-.09-5.31-1.41c-.19-.19-.19-.51 0-.7.19-.19.51-.19.7 0 1.01 1.01 3.19 1.11 4.61 1.11s3.6-.1 4.61-1.11c.19-.19.51-.19.7 0 .19.19.19.51 0 .7zm-2.31-4.14c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
    </svg>
  </div>

  {/* 3. Twitter / X */}
  <div style={iconFrameBase}>
    <svg style={iconSvgStyle} viewBox="0 0 24 24">
      <path fill="black" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
    </svg>
  </div>

  {/* 4. Discord */}
  <div style={iconFrameBase}>
    <svg style={iconSvgStyle} viewBox="0 0 24 24">
      <path fill="black" d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
    </svg>
  </div>
</div>
        </div>
        </div>
    </div>
    <div style={Column2Style}>
        <div style={textAreaStyle}>
            <div style={messageFrameStyle}>
                <div style={bigFontBoxStyle}>
                    <span style={florasheenStyles}>
                        Let's
                    </span>
                    <span style={developerStyles}>talk</span>
                    <span style={florasheenStyles}>
                        for
                    </span>
                </div>
                <div style={bigFontBoxStyle}>
                    <span style={florasheenStyles}>
                        Something special
                    </span>
                </div>
                <p style={paragraphStyle}>
                    I seek to push the limits of creativity to create high-engaging, user-friendly, and memorable interactive experiences.
                </p>
            </div>
            <div style={informationFrameStyle}>
                <p style={informationTextStyle}>
                    Yourmail@gmail.com
                </p>
                <p style={informationTextStyle}>
                    1234567890
                </p>
            </div>
        </div>
    </div>
</div>
)
}