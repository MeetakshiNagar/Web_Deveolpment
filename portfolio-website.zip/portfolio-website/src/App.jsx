import Header from "./Header";
import Hero from './Hero'
import { Skills } from "./Skills";
import Experience from "./Experience";
import AboutMe from "./AboutMe";
import Testinomial from "./Testinomial";
import Contact from "./Contact";
import Footer from "./Footer";
import Project from "./Project";

export default function App() {
  return (
    <div>
    <Header/>
    <Hero />
    <Skills />
    <Experience/>
    <AboutMe />
    <Project />
    <Testinomial/>
    <Contact/>
    <Footer/>
    </div>
  );
}

