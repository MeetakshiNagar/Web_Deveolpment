import girl2 from './girl2.png'

export default function Footer()
{
    const footerSectionStyle = {
  width: '1440px',
  height: '100px',
  padding: '24px 80px', // 24px Top/Bottom, 80px Left/Right
  backgroundColor: '#000000', // Footers in this style are usually black or match the theme
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
  margin: '0 auto', // Centers the footer on the page
  opacity: 1,
  boxSizing: 'border-box',
};
const footerContainerStyle = {
  width: '1280px',
  height: '52px',
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: '0 32px', // 32px Left/Right inside the 1280px width
  margin: '0 auto',   // Centers this container within the 1440px footer
  color: '#FFFFFF',
  opacity: 1,
  boxSizing: 'border-box',
};
const FrameStyle = {
  width: '139.91px', // Rounded for cleaner CSS
  height: '40px',
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  gap: '12px',
  opacity: 1,
  boxSizing: 'border-box',
};
const Frame2Style = {
  width: '181px',
  height: '52px',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'flex-end', // Aligns icons/text to the right edge
  gap: '12px',
  opacity: 1,
  boxSizing: 'border-box',
};
const LogoStyle = {
  width: '100px',
  height: '34.73px',
  position: 'absolute',
  top: '2.64px',
  left: '8.38px',
  opacity: 1,
  // If this is an SVG path, you might need:
  display: 'block',
  boxSizing: 'border-box',
};
    return(
       <div style={footerSectionStyle}>
        <div style={footerContainerStyle}>
            <div style={FrameStyle}>
                {/* <div style={LogoStyle}> */}
            <img src={girl2} style={{width:'25px'}}/>
            {/* </div> */}
                Personal
            </div>
            <div style={Frame2Style}>
                <span>@ 2019-2023 Personal</span>
                <span>Made In Figma</span>
            </div>
        </div>
       </div> 
    )
}