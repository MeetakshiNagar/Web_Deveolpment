import girl1 from './girl1.png';
import girl2 from './girl2.png';

export default function Testinomial()
{
    const testimonialSectionStyle = {
  width: '1440px',
  height: '714px',
  margin: '0 auto', // Centers the 1440px section if the screen is wider
  padding: '60px 80px', // Top/Bottom 60, Left/Right 80
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center', // Usually testimonials are centered
  justifyContent: 'center',
  backgroundColor: '#FFFFFF', // Or your specific theme color
  opacity: 1,
  boxSizing: 'border-box', // Crucial to keep padding inside the 1440 width
};
const testimonialCardStyle = {
  width: '370px',
  height: '398px',
  display: 'flex',
  flexDirection: 'column',
  gap: '24px',
  padding: '40px',
  backgroundColor: '#FFFFFF',
  borderRadius: '20px',
  opacity: 1,
  boxSizing: 'border-box',
  // Combining your two shadow specs into a single CSS property
  boxShadow: `
    0px 8px 16px -6px rgba(24, 39, 75, 0.08), 
    0px 6px 8px -6px rgba(24, 39, 75, 0.12)
  `,
  marginRight:'30px',
  justifyContent:'center',
  alignItems:'center',
  alignSelf: 'center'
};
const BlacktestimonialCardStyle = {
  width: '370px',
  height: '398px',
  display: 'flex',
  flexDirection: 'column',
  gap: '24px',
  padding: '40px',
  backgroundColor: '#000000',
  borderRadius: '20px',
  opacity: 1,
  boxSizing: 'border-box',
  // Combining your two shadow specs into a single CSS property
  boxShadow: `
    0px 8px 16px -6px rgba(24, 39, 75, 0.08), 
    0px 6px 8px -6px rgba(24, 39, 75, 0.12)
  `,
  marginRight:'30px'
};
const avatarFrameStyle = {
  width: '96px',
  height: '96px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: '10px',
  borderRadius: '50%', // Circular frame for the testimonial face
  overflow: 'hidden',   // Ensures the image doesn't spill out of the circle
  opacity: 1,
  backgroundColor: '#F4F4F5', // Light grey placeholder
  border: '2px solid #000000', // Optional: adds a crisp outline like your "About Me" frame
};

const avatarImageStyle = {
  width: '100%',
  height: '100%',
  objectFit: 'cover', // Ensures the face isn't stretched
};
const separatorLineStyle = {
  width: '120px',
  height: '2px',
  backgroundColor: '#000000', // Matches your "About Me" border weight
  margin: '8px 0',          // Adds vertical breathing room
  border: 'none',           // Clears default <hr> styling
  opacity: 1,
};
const highlightedseparatorLineStyle = {
  width: '120px',
  height: '2px',
  backgroundColor: 'white', // Matches your "About Me" border weight
  margin: '8px 0',          // Adds vertical breathing room
  border: 'none',           // Clears default <hr> styling
  opacity: 1,
};
const quoteTextStyle = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 400,
  fontSize: '16px',
  lineHeight: '20px',    // The tight leading from your specs
  letterSpacing: '0.02em', // 2% letter spacing
  textAlign: 'center',
  color: '#404040',      // The specific dark grey
  margin: 0,
  opacity: 1,
};

// Logic for the highlighted (black) card:
const highlightedQuoteStyle = {
  ...quoteTextStyle,
  color: '#FFFFFF', // Flip to white when the background is black
};
const designationStyle = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 600,
  fontSize: '16px',
  lineHeight: '20px',
  letterSpacing: '-0.02em', // -2% letter spacing
  textAlign: 'center',
  color: '#71717A',        // The cool grey from your specs
  margin: 0,
  opacity: 1,
};

// For the highlighted (black) card, we'll soften this slightly
const highlightedDesignationStyle = {
  ...designationStyle,
  color: '#D4D4D8', // Light grey for contrast on black
};
const NameStyle = {
  // Typography Specs
  fontFamily: 'Sora, sans-serif',
  fontWeight: 600,             // SemiBold
  fontSize: '20px',
  lineHeight: '24px',
  letterSpacing: '-0.02em',    // -2%
  
  // Alignment & Formatting
  textAlign: 'center',
  textTransform: 'capitalize',
  
  // Color & Visuals
  color: '#404040',            // Dark grey from your spec
  margin: '0 0 4px 0',         // Small bottom margin to separate from Designation
  opacity: 1,
  fontStyle: 'normal'          // Ensuring it's "Regular/Normal" style as per your "SemiBold" request
};
const highlightedNameStyle = {
  ...NameStyle,
  color: '#FFFFFF' // Pure white for the inverted card
};
const headingStyles = {
  width: '1216px',
  height: '96px',
  display: 'flex',
  flexDirection: 'column', // Stacks title and subtitle vertically
  justifyContent: 'center', // Centers content vertically within the 96px height
  alignItems: 'center',     // Centers content horizontally
  paddingTop: '20px',
  paddingBottom: '20px',
  gap: '16px',
  transform: 'rotate(0deg)',
  opacity: 1,
  boxSizing: 'border-box',
  margin: '0 auto'          // Keeps it centered within the 1280px container
};
const myTextStyles = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 400,
  fontStyle: 'normal',
  fontSize: '48px',
  lineHeight: '56px',
  letterSpacing: '-0.96px', // -2% of 48px
  marginRight: '15px',
  display: 'inline-block', // Keeps it on the same line as the next word
  opacity: 1,
};
const skillsTextStyle = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 800,
  fontStyle: 'normal', // ExtraBold is defined by the 800 weight
  fontSize: '48px',
  lineHeight: '56px',
  letterSpacing: '-0.96px', // -2% of 48px
  margin: 0,
  display: 'inline-block',
  opacity: 1,
};
return(
    <>
     <div style={headingStyles}>
  <h2 style={{ margin: 0 }}>
    <span style={myTextStyles}>My</span> {/* Added a space here */}
    <span style={skillsTextStyle}>Testinomial</span>
  </h2>
</div>
    <div style={testimonialSectionStyle}>
        <div style={testimonialCardStyle}>
            <div style={avatarFrameStyle}>
                <div style={avatarImageStyle}>
                    <img src={girl1} />
                </div>
            </div>
            <p style={quoteTextStyle}>I recently had to jump on 10+ different calls across eight different countries to find the right owner.</p>
            <div style={separatorLineStyle}></div>
            <div style={NameStyle}>Evem</div>
            <div style={designationStyle}>Designer</div>
        </div>

        <div style={BlacktestimonialCardStyle}>
            <div style={avatarFrameStyle}>
                <div style={avatarImageStyle}>
                    <img src={girl1} />
                </div>
            </div>
            <p style={highlightedQuoteStyle}>I recently had to jump on 10+ different calls across eight different countries to find the right owner.</p>
            <div style={highlightedseparatorLineStyle}></div>
            <div style={highlightedNameStyle}>Evem</div>
            <div style={highlightedDesignationStyle}>Designer</div>
        </div>

        <div style={testimonialCardStyle}>
            <div style={avatarFrameStyle}>
                <div style={avatarImageStyle}>
                    <img src={girl1} />
                </div>
            </div>
            <p style={quoteTextStyle}>I recently had to jump on 10+ different calls across eight different countries to find the right owner.</p>
            <div style={separatorLineStyle}></div>
            <div style={NameStyle}>Evem</div>
            <div style={designationStyle}>Designer</div>
        </div>
    </div>
    </>
)
}