import Icon from './Icon.png'
import './header.css'
import girl2 from './girl2.png'
function Header()
{
    return(
        <div className="header">
            <a style={{display:'flex'}}><img src={girl2} style={{width:'30px',height:'30px'}}/>Personal</a>
            <div className="taskbar">
            <a className="tasks">About Me</a>
            <a className="tasks">Skills</a>
            <a className="tasks">Project</a>
            <a className="tasks">Contact Me</a>
            </div>
            <button className="resume-button">Resume <img src={Icon} /></button>
        </div>
    )
}

export default Header