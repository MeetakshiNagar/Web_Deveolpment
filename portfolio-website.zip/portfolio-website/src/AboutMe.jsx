import girl2 from './girl2.png';

export default function AboutMe() {
  const aboutMeContainerStyle = {
    width: '1216px',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'flex-start', // Keeps text aligned to the top of the image
    gap: '80px',              // Increased gap for a more premium feel
    padding: '96px 0',
    margin: '0 auto',
    justifyContent: 'center'
  };

  const imageFrameStyle = {
    width: '518px',           
    height: '518px',          
    position: 'relative', 
    border: '4px solid #000000', // Changed from 8px white to 1px black to match the sketch style
    borderRadius: '12px',    
    overflow: 'hidden',
    left:'32px',
    overflow:'overflow'
  };

  const illustrationStyle = {
    width: '349.06px',
    height: '554.69px',
    position: 'absolute',     
    top: '37.59px',
    left: '116.76px',
    opacity: 1,
    objectFit: 'contain',
  };

  const textContentStyle = {
    flex: '1', 
    display: 'flex',
    flexDirection: 'column',
    gap: '24px', 
  };

  const paragraphStyle = {
    fontFamily: 'Sora, sans-serif',
    fontWeight: 400,
    fontSize: '16px',
    lineHeight: '24px',
    letterSpacing: '0.02em',
    width: '100%',    // FIX: Changed from 1120px to 100%
    margin: 0,        // FIX: Let the parent gap handle spacing
    textAlign: 'left',
    color:'#71717A'
  };

  return (
    <section style={aboutMeContainerStyle}>
      {/* Left Side */}
      <div style={imageFrameStyle}>
        <img src={girl2} alt="Illustration" style={illustrationStyle} />
      </div>

      {/* Right Side */}
      <div style={textContentStyle}>
        <h2 style={{ 
          fontFamily: 'Sora', 
          fontSize: '36px', 
          fontWeight: 400, 
          margin: 0,
        }}>
          About <span style={{ fontWeight: 800 }}>Me</span>
        </h2>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <p style={paragraphStyle}>
            I'm a passionate, self-proclaimed designer who specializes in full stack development (React.js & Node.js). I am very enthusiastic about bringing the technical and visual aspects of digital products to life. User experience, pixel perfect design, and writing clear, readable, highly performant code matters to me.
          </p>
          <p style={paragraphStyle}>
            I began my journey as a web developer in 2015, and since then, I've continued to grow and evolve as a developer, taking on new challenges and learning the latest technologies along the way. Now, in my early thirties, 7 years after starting my web development journey, I'm building cutting-edge web applications using modern technologies such as Next.js, TypeScript, Nestjs, Tailwindcss, Supabase and much more.
          </p>
          <p style={paragraphStyle}>
            When I'm not in full-on developer mode, you can find me hovering around on twitter or on indie hacker, witnessing the journey of early startups or enjoying some free time. You can follow me on Twitter where I share tech-related bites and build in public, or you can follow me on GitHub.
          </p>
        </div>
      </div>
    </section>
  );
}