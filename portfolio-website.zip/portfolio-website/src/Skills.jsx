export function Skills()
{
    const skillsSectionStyles = {
  width: '1440px',
  height: '728px',
  padding: '60px 80px', // Shortcut for Top/Bottom 60, Left/Right 80
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',    // Centers content horizontally
  justifyContent: 'center', // Centers content vertically (optional, depends on design)
  transform: 'rotate(0deg)',
  opacity: 1,
  boxSizing: 'border-box',
  backgroundColor: '#FFFFFF' // Or whatever your section background color is
};
    const containerStyles = {
  width: '1280px',
  height: '608px',
  display: 'flex',
  flexDirection: 'column', // Or 'row' if the items go side-by-side
  alignItems: 'center',    // Centers items horizontally
  paddingLeft: '32px',
  paddingRight: '32px',
  gap: '20px',
  transform: 'rotate(0deg)',
  opacity: 1,
  boxSizing: 'border-box',
  margin: '0 auto'         // This keeps the 1280px container centered inside the 1440px section
};
const headingStyles = {
  width: '1216px',
  height: '96px',
  display: 'flex',
  flexDirection: 'column', // Stacks title and subtitle vertically
  justifyContent: 'center', // Centers content vertically within the 96px height
  alignItems: 'center',     // Centers content horizontally
  paddingTop: '20px',
  paddingBottom: '20px',
  gap: '16px',
  transform: 'rotate(0deg)',
  opacity: 1,
  boxSizing: 'border-box',
  margin: '0 auto'          // Keeps it centered within the 1280px container
};
const myTextStyles = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 400,
  fontStyle: 'normal',
  fontSize: '48px',
  lineHeight: '56px',
  letterSpacing: '-0.96px', // -2% of 48px
  marginRight: '15px',
  display: 'inline-block', // Keeps it on the same line as the next word
  opacity: 1,
};
const skillsTextStyle = {
  fontFamily: 'Sora, sans-serif',
  fontWeight: 800,
  fontStyle: 'normal', // ExtraBold is defined by the 800 weight
  fontSize: '48px',
  lineHeight: '56px',
  letterSpacing: '-0.96px', // -2% of 48px
  margin: 0,
  display: 'inline-block',
  opacity: 1,
};
const row1Styles = {
  width: '1216px',
  height: '226px',
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center', // Centers icons vertically within the 226px height
  paddingTop: '20px',
  paddingBottom: '20px',
  transform: 'rotate(0deg)',
  opacity: 1,
  boxSizing: 'border-box'
};
const skillCardStyle = {
  width: '186px',
  height: '186px',
  display: 'flex',
  flexDirection: 'column', // Stacks the icon above the text
  alignItems: 'center',    // Centers icon/text horizontally
  justifyContent: 'center', // Centers icon/text vertically
  padding: '24px',
  gap: '32px',
  backgroundColor: '#FFFFFF',
  border: '2px solid #000000',
  borderRadius: '4px',
  transform: 'rotate(0deg)',
  opacity: 1,
  boxSizing: 'border-box',
  transition: 'transform 0.2s ease' // Optional: adds a nice "pop" if you hover over it later
};

const SkillCard = ({ name, iconPath, isInverted = false, viewBox = "0 0 24 24" }) => {
  const customCardStyle = {
    ...skillCardStyle,
    backgroundColor: isInverted ? '#000000' : '#FFFFFF',
    color: isInverted ? '#FFFFFF' : '#000000',
  };

  return (
    <div style={customCardStyle}>
      <div style={{ width: '56px', height: '56px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <svg viewBox={viewBox} style={{ width: '100%', height: '100%' }}>
          <path d={iconPath} fill={isInverted ? "white" : "black"} />
        </svg>
      </div>
      <span style={{ fontFamily: 'Sora', fontWeight: 700, fontSize: '20px' }}>
        {name}
      </span>
    </div>
  );
};

const iconPaths = {
  git: "M2.6 10.59L11.59 1.6a1.42 1.42 0 0 1 2 0l8.8 8.8a1.42 1.42 0 0 1 0 2l-8.8 8.8a1.42 1.42 0 0 1-2 0l-8.99-9a1.42 1.42 0 0 1 0-2Zm10.91 3.19a1.77 1.77 0 1 0-1.77 1.77 1.77 1.77 0 0 0 1.77-1.77Zm-2.61-4.78v2.73a1.77 1.77 0 1 0 1.2 0V9a1.77 1.77 0 1 0-1.2 0Z",
  javascript: "M3 3h18v18H3V3zm11.54 11.81c0 .88.3 1.25 1.25 1.25.75 0 1.12-.23 1.12-.91 0-.61-.31-.83-1.05-1.14l-.3-.13c-1.3-.55-1.89-1.28-1.89-2.58 0-1.54 1.05-2.3 2.74-2.3 1.61 0 2.59.68 2.59 2.18h-1.39c0-.75-.38-1.05-1.16-1.05-.68 0-1.13.23-1.13.83 0 .53.23.75 1.05 1.13l.3.11c1.47.64 2.03 1.24 2.03 2.62 0 1.73-1.13 2.45-2.89 2.45-1.88 0-2.85-.86-2.85-2.4h1.39zM8.38 10h1.43v5.27c0 1.28-.53 1.84-1.61 1.84-.53 0-1-.15-1.28-.34l.23-1.13c.19.11.45.19.71.19.45 0 .53-.23.53-.72V10z",
  sass: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.41 12.3c-.56.64-1.34 1.1-2.34 1.37-.2.05-.41.08-.62.08-.6 0-1.13-.19-1.58-.57-.45-.37-.76-.88-.93-1.52-.16.1-.33.19-.52.28-.84.39-1.74.59-2.68.59-1.03 0-1.86-.25-2.49-.75s-.94-1.22-.94-2.15c0-1.11.39-1.98 1.18-2.6.79-.62 1.85-.94 3.19-.94.75 0 1.45.1 2.09.31l.07.03c-.02-.1-.03-.21-.03-.31 0-.61.16-1.07.49-1.38.33-.31.81-.46 1.43-.46.54 0 1 .11 1.38.33l-.44 1.13c-.2-.1-.43-.16-.67-.16-.21 0-.38.06-.5.18-.12.12-.18.3-.18.53 0 .15.02.29.07.44l.84 2.6c.11.33.16.66.16 1 0 .68-.19 1.21-.57 1.59z",
  nest: "M12 2L3 7v10l9 5 9-5V7l-9-5zm6.5 14.25l-6.5 3.6-6.5-3.6V8.75l6.5-3.6 6.5 3.6v7.75zM12 8.5l-4 2.25v2.5l4 2.25 4-2.25v-2.5L12 8.5z",
  storybook: "M20 2H4c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-6 16h-4v-2h4v2zm2-4H8V6h8v8z",
  socket: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm1.64-5.32l-.92.92C12.91 13.41 12.5 14 12.5 15h-1c0-1.38.56-2.63 1.46-3.54l.62-.62c.18-.18.32-.38.41-.61.1-.23.15-.48.15-.73 0-.55-.22-1.05-.59-1.41-.36-.37-.86-.59-1.41-.59s-1.05.22-1.41.59c-.37.36-.59.86-.59 1.41h-1c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.96 2.27z"
};

    return(
        <div style={skillsSectionStyles}>

<div style={containerStyles}>

    <div style={headingStyles}>
  <h2 style={{ margin: 0 }}>
    <span style={myTextStyles}>My</span> {/* Added a space here */}
    <span style={skillsTextStyle}>Skills</span>
  </h2>
</div>

  {/* ROW 1 */}
  <div style={row1Styles}>
    <SkillCard name="Git" iconPath={iconPaths.git} />
    <SkillCard name="Javascript" iconPath={iconPaths.javascript} isInverted={true} />
    <SkillCard name="Sass/Scss" iconPath={iconPaths.sass} />
    <SkillCard name="Nest.Js" iconPath={iconPaths.nest} />
    <SkillCard name="Storybook" iconPath={iconPaths.storybook} />
  </div>

  {/* ROW 2 */}
  <div style={{ ...row1Styles, marginTop: '20px' }}>
    <SkillCard name="Nest.Js" iconPath={iconPaths.nest} />
    <SkillCard name="Git" iconPath={iconPaths.git} />
    <SkillCard name="Storybook" iconPath={iconPaths.storybook} />
    <SkillCard name="Socket.io" iconPath={iconPaths.socket} />
    <SkillCard name="Sass/Scss" iconPath={iconPaths.sass} />
  </div>
</div>
        </div>
    )
}