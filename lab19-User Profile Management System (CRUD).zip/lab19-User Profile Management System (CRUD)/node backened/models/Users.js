const mongoose = require('mongoose');

// Define the User Schema
const userSchema = new mongoose.Schema({
    fullName: {
        type: String,
        required: [true, 'Full Name is required'] // Rule: String, Required
    },
    email: {
        type: String,
        required: [true, 'Email is required'],
        unique: true, // Rule: Must be unique
        trim: true
    },
    age: {
        type: Number,
        min: [18, 'Age must be at least 18'] // Rule: Number, at least 18
    },
    city: {
        type: String, // Rule: String, Optional (default behavior)
        required: false 
    },
    isActive: {
        type: Boolean,
        default: true // Rule: Boolean, Default is true
    },
    createdAt: {
        type: Date,
        default: Date.now // Rule: Date, default to current date/time
    }
});

// Export the model
module.exports = mongoose.model('User', userSchema);