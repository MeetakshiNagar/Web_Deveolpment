const mongoose = require("mongoose");

// Step 2: Connect to Atlas
mongoose.connect("mongodb+srv://myUser:myPassword@cluster0.abcd.mongodb.net/myDatabase", {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log("✅ Connected to MongoDB Atlas"))
.catch(err => console.error("❌ Connection error:", err));

// Step 3: Define Schema & Model
const studentSchema = new mongoose.Schema({
  name: String,
  major: String,
  year: Number
});

const Student = mongoose.model("Student", studentSchema);

// Step 4: Create & Save a Document
const newStudent = new Student({
  name: "Alice",
  major: "Computer Science",
  year: 2
});

newStudent.save()
  .then(() => console.log("🎉 Student saved"))
  .catch(err => console.error(err));

// Step 5: Read Data
Student.find()
  .then(students => console.log("📚 Students:", students))
  .catch(err => console.error(err));