    require('dotenv').config();
const express = require("express");
const mongoose = require("mongoose");
const User = require('./models/Users'); // Ensure your file is named User.js in models folder

const app = express();

// 1. MIDDLEWARE (Crucial for reading JSON from Postman)
app.use(express.json());

// 2. CONNECT TO MONGODB
// Note: Use process.env.MONGO_URI here once you move the string to your .env file
mongoose.connect("mongodb+srv://iit2025234:MongoDB%40100@mongodb-practice.efcrcck.mongodb.net/?appName=MongoDB-Practice")
  .then(() => console.log("✅ Connected to MongoDB Atlas"))
  .catch(err => console.error("❌ Connection error:", err));

// --- CRUD ROUTES FOR USERS (Assignment Part 4) ---

// A. CREATE (POST)
app.post('/api/users', async (req, res) => {
    try {
        const newUser = new User(req.body); 
        await newUser.save();
        res.status(201).json({ message: "User created!", user: newUser });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// B. READ ALL (GET)
app.get('/api/users', async (req, res) => {
    try {
        const users = await User.find();
        res.json(users);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// C. READ SINGLE (GET)
app.get('/api/users/:id', async (req, res) => {
    try {
        const user = await User.findById(req.params.id);
        if (!user) return res.status(404).json({ message: "User not found" });
        res.json(user);
    } catch (error) {
        res.status(400).json({ error: "Invalid ID format" });
    }
});

// D. UPDATE (PUT)
app.put('/api/users/:id', async (req, res) => {
    try {
        const updatedUser = await User.findByIdAndUpdate(
            req.params.id, 
            req.body, 
            { new: true, runValidators: true }
        );
        if (!updatedUser) return res.status(404).json({ message: "User not found" });
        res.json(updatedUser);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// E. DELETE (DELETE)
app.delete('/api/users/:id', async (req, res) => {
    try {
        const deletedUser = await User.findByIdAndDelete(req.params.id);
        if (!deletedUser) return res.status(404).json({ message: "User not found" });
        res.json({ message: "User deleted successfully" });
    } catch (error) {
        res.status(400).json({ error: "Error deleting user" });
    }
});

// 3. START SERVER
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});