import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import bcrypt from 'bcrypt';

const dbUrl = 'mongodb+srv://iit2025234:MongoDB%40100@mongodb-practice.efcrcck.mongodb.net/?appName=MongoDB-Practice';

mongoose.connect(dbUrl)
  .then(() => console.log("Connected to MongoDB!"))
  .catch(err => console.error("Database connection error:", err));

const userSchema = new mongoose.Schema({
  username: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  selectedTeam: { type: Array, default: [] },
  budget: { type: Number, default: 1000 }
});
const User = mongoose.model('User', userSchema);

const app = express();
app.use(cors());
app.use(express.json()); 

// --- ROUTES ---

app.get('/test', (req, res) => {
  res.send("Hello from the Backend!");
});

app.post('/signup', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newUser = new User({ username, email, password: hashedPassword });
    await newUser.save();
    
    console.log("User saved:", username);
    res.status(201).json({ message: "User secured and saved! , Please login now." });
  } catch (error) {
    console.error("Signup Error:", error); // This helps you see the REAL error in terminal
    res.status(400).json({ message: "Signup failed. Email might exist. Try logging in instead. Or try a different email." });
  }
});

app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log("Login attempt for:", email);

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: "User not found!" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials!" });
    }

    res.json({ message: "Welcome back!", username: user.username, selectedTeam: user.selectedTeam, budget: user.budget });
  } catch (error) {
    console.error("Login Error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

app.post('/save-team', async (req, res) => {
  const { email, selectedTeam, budget } = req.body;
  try {
    await User.findOneAndUpdate({ email }, { selectedTeam, budget });
    res.json({ message: "Team synced to cloud!" });
  } catch (error) {
    res.status(500).json({ message: "Failed to save team" });
  }
});

app.listen(5000, () => console.log("Server is awake on port 5000"));