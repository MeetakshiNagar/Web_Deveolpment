import { useState ,useEffect } from "react";

function SignUp() 
    {
        useEffect(() => {
  fetch('http://localhost:5000/test')
    .then(response => response.text())
    .then(data => console.log("Backend says:", data))
    .catch(err => console.log("Connection failed!", err));
}, []);


        const [formData, setFormData] = useState({
            username: '',
            email: '',
            password: '',
            confirmPassword: ''
        });
        
        const handleChange = (e) => {
            const { name, value } = e.target;
            setFormData({...formData, [name]: value });
        };

const handleSignup = async (e) => {
    e.preventDefault();
    
    const signupData = {
        username: formData.username,
        email: formData.email,
        password: formData.password
    };

    try {
        const response = await fetch('http://localhost:5000/signup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(signupData) // Send clean data
        });
        const result = await response.json();
        alert(result.message);
    } catch (err) {
        alert("Connection to server failed!");
    }
};

const style={marginBottom:'20px', padding:'10px 20px', borderRadius:'5px', border:'black solid 1px', cursor:'pointer', backgroundColor:'antiquewhite', color:'#2549e9'};

  const Loginstyle={marginBottom:'20px', padding:'10px 20px', borderRadius:'5px', border:'none', cursor:'pointer', backgroundColor:'rgba(0, 0, 0, 0.7)', color:'white',Display:'inline'};
        return (
    <div className="signup-container">
      <div className="signup-card">
        <h2>Create Account</h2>
        <form className="signup-form" onSubmit={handleSignup} style={{display:'flex',flexDirection:'column'}}>
            <input 
            type="text" name="username" placeholder="Username" 
            onChange={handleChange} required style={style}
          />
          <input 
            type="email" name="email" placeholder="Email Address" 
            onChange={handleChange} required style={style}
          />
          <input 
            type="password" name="password" placeholder="Password" 
            onChange={handleChange} required style={style}
          />
          <button type="submit" style={Loginstyle}>Join League</button>
            </form>
        </div>
    </div>
  );
}


export default SignUp;    