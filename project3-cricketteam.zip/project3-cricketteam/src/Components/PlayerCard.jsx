function PlayerCard({ player, onCardClick, Choice }) {
  // A generic profile icon as a fallback
  const fallback = "https://www.cricbuzz.com/a/img/v1/152x152/i1/c153372/ravichandran-ashwin.jpg";

  return (
    <div className='Card'>
      <div className='image-container'>
        <img 
          src={player.PlayerPhoto} 
          alt={player.Playername} 
          onError={(e) => { e.target.src = fallback; }}
          style={{ width: '100%', borderRadius: '8px' }}
        />
      </div>
      <p><strong>{player.Playername}</strong></p>
      <p>Price: {player.Salary}</p>
      {Choice && (
        <button 
          onClick={() => onCardClick(player)} 
          className={Choice === "Select" ? "BUTTON_Select" : "BUTTON_DeSelect" }
          style={{width:'100px', height:'40px', borderRadius:'5px', border:'none', cursor:'pointer'}}
        >
          {Choice}
        </button>
      )}
    </div>
  )
}
export default PlayerCard;