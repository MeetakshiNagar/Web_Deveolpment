import { useState } from 'react';
import Display from './Display';

function Login({isLoggedIn, setisLoggedIn}) {
  const [loginData, setLoginData] = useState({
    email: '',
    password: ''
  });

  const handleChange = (e) => {
    setLoginData({ ...loginData, [e.target.name]: e.target.value });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5000/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginData)
      });
      const result = await response.json();
      
      if (response.ok) {
        alert("Login successful!");
        setisLoggedIn(true);
        // We will handle "keeping the user logged in" in the next step
      } else {
        alert(result.message);
      }
    } catch (err) {
      alert("Server error!");
    }
  };

  const style={marginBottom:'20px', padding:'10px 20px', borderRadius:'5px', border:'black solid 1px', cursor:'pointer', backgroundColor:'antiquewhite', color:'#2549e9'};

  const Loginstyle={marginBottom:'20px', padding:'10px 20px', borderRadius:'5px', border:'none', cursor:'pointer', backgroundColor:'rgba(0, 0, 0, 0.7)', color:'white',Display:'inline'};

  return (
    <div className="login-page">
      <div className="signup-card"> {/* Reuse the same CSS class for consistency */}
        <h2>Manager Login</h2>
        <form onSubmit={handleLogin} style={{display:'flex',flexDirection:'column'}}>
          <input 
            type="email" name="email" placeholder="Email Address" 
            onChange={handleChange} required style={style}
          />
          <input 
            type="password" name="password" placeholder="Password" 
            onChange={handleChange} required style={style}
          />
          <button type="submit" style={Loginstyle}>Login</button>
        </form>
      </div>
    </div>
  );
}

export default Login;

