import PlayerCard from "./PlayerCard.jsx";

//IMPORTANT:here the .map() used can be used only for array and not any random object
function List({ players, onPlayerClick,Choice,moneyleft ,count}) {
  let affordablePlayers=30-count;

  function CalculateaffordablePlayers(player){

    if(player.Salary>moneyleft)
    {
      affordablePlayers--;
    }
    return affordablePlayers
  }
  return (
    <div className='cards-container'>
      {players.map((player, index) => (
        <>
        <PlayerCard 
          key={index} 
          player={player} // Pass the whole player object!
          onCardClick={() => onPlayerClick && onPlayerClick(player)}
          Choice={Choice=="Select"?(player.Salary<=moneyleft?(Choice):("Not Affordable")):Choice} 
        />
        {CalculateaffordablePlayers(player)==0 && setTimeout(()=>alert("No more players are affordable"),10)}
        </>                          ))                          
      }
    </div>
  );
}

export default List;

