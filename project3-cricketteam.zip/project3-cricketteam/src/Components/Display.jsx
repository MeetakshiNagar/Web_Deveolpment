import List from './List.jsx';
import { useState, useEffect } from "react";

function Display({ available, selected, onAvailable,onSelect,count,moneyleft }) {
  
  const[isFinalized,setisFinalized]=useState(false);
  function ButtonContent(){
  if(count==11){
    return "Completed";
  } }

  return (
    <>
    <h3 style={{ color: 'gray', textAlign: 'center' }}>Finalize The Team You Think Is Ideal For Today's Match And Share Your Opinions With Others</h3>
    <div style={{display:"flex"}} id="Display">
      {!isFinalized && <div className='Available'>
        <h2>Available Players</h2>
        <List players={isFinalized?[]:available} onPlayerClick={onAvailable} Choice={count<11?"Select":"Players Limit reached"} moneyleft={moneyleft} count={count}/>
{/*IMPORTANT::"Select" is correct but {Select} or {"Select"} are wrong because here it is treated as variable Which is not defined*/}        
      </div>
      }

      <div className='Selected'>
        <h2 style={{ color: 'rgba(249, 240, 208, 0.8)' }}>Selected Players</h2>
        <List players={selected} onPlayerClick={onSelect} Choice={!isFinalized?"Deselect":''} count={count}/>
        {
  !isFinalized && count === 11 && (
    <button
      onClick={() => {
        setisFinalized(true);
        localStorage.setItem("finalTeam", JSON.stringify(selected));
        localStorage.setItem("Remaining Players", JSON.stringify(available));
        alert("Team finalized!");
      }}
      className="BUTTON_Select"
      style={{marginTop: '20px', cursor: 'pointer',backgroundColor:'yellow',borderRadius:'5px'}}
    >
      {ButtonContent()}
    </button>
  )
}
   {isFinalized && (
    <button id="screenshotBtn" onClick={() => window.print()} className="BUTTON_Select" style={{marginTop: '20px', cursor: 'pointer',backgroundColor:'yellow',borderRadius:'5px'}}>
      Print Team
    </button>
  )}


      </div>
    </div>  
    </>
  )
}
export default Display;  

