const initialPlayers = [
  // --- INDIA ---
  { id: 1, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170661/virat-kohli.jpg", Playername: "Virat Kohli", Salary: 150 },
  { id: 2, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170658/rohit-sharma.jpg", Playername: "Rohit Sharma", Salary: 140 },
  { id: 3, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170677/ms-dhoni.jpg", Playername: "MS Dhoni", Salary: 130 },
  { id: 4, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170685/jasprit-bumrah.jpg", Playername: "Jasprit Bumrah", Salary: 140 },
  { id: 5, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170666/ravindra-jadeja.jpg", Playername: "Hardik Pandya", Salary: 120 },
  { id: 6, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170664/hardik-pandya.jpg", Playername: "Vijay Shankar", Salary: 125 },
  { id: 7, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c196655/suryakumar-yadav.jpg", Playername: "Suryakumar Yadav", Salary: 110 },
  { id: 8, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c216335/shubman-gill.jpg", Playername: "Babar Azam", Salary: 100 },
  { id: 9, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170673/kl-rahul.jpg", Playername: "KL Rahul", Salary: 105 },
  { id: 10, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c171010/rishabh-pant.jpg", Playername: "Rishabh Pant", Salary: 115 },
  { id: 11, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170684/mohammed-shami.jpg", Playername: "Mohammed Shami", Salary: 100 },
  { id: 12, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c153372/ravichandran-ashwin.jpg", Playername: "Ravichandran Ashwin", Salary: 90 },
  { id: 13, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c171019/shreyas-iyer.jpg", Playername: "Manish Pandey", Salary: 95 },
  
  // --- AUSTRALIA ---
  { id: 14, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170651/pat-cummins.jpg", Playername: "Pat Cummins", Salary: 130 },
  { id: 15, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170640/david-warner.jpg", Playername: "Usman Khawaja", Salary: 115 },
  { id: 16, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170652/mitchell-starc.jpg", Playername: "Mitchell Starc", Salary: 125 },
  { id: 17, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170639/steve-smith.jpg", Playername: "Steve Smith", Salary: 110 },

  // --- OTHERS ---
  { id: 21, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170733/kane-williamson.jpg", Playername: "Kane Williamson", Salary: 120 },
  { id: 22, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170743/trent-boult.jpg", Playername: "Trent Boult", Salary: 115 },
  { id: 23, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170961/rashid-khan.jpg", Playername: "Rashid Khan", Salary: 135 },
  { id: 24, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170934/jos-buttler.jpg", Playername: "Jos Buttler", Salary: 120 },
  { id: 25, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170915/ben-stokes.jpg", Playername: "Ben Stokes", Salary: 125 },
  { id: 26, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170700/babam-azam.jpg", Playername: "Babar Azam", Salary: 130 },
  { id: 27, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170617/quinton-de-kock.jpg", Playername: "Quinton de Kock", Salary: 110 },
  { id: 28, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170625/kagiso-rabada.jpg", Playername: "Kagiso Rabada", Salary: 115 },
  { id: 29, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170897/shakib-al-hasan.jpg", Playername: "Shakib Al Hasan", Salary: 105 },
  { id: 30, PlayerPhoto: "https://www.cricbuzz.com/a/img/v1/152x152/i1/c170925/joe-root.jpg", Playername: "Joe Root", Salary: 110 }
];

export default initialPlayers;
