import { use, useEffect, useState } from 'react';
import Display from './Components/Display.jsx';
import initialPlayers from './Components/InitialPlayers.jsx';
import SignUp from './Components/SignUp.jsx'; 
import Login from './Components/Login.jsx';
import CricketImage from './vector-logo-for-cricket-sport-creative-contour-illustration-of-hitting-ball-in-goal-original-decorative-brush-typeface-for-word-cricket-simplistic-WAF2P4.jpg';

function App() {
  // Manage both lists using state
  const [availablePlayers, setAvailablePlayers] = useState(initialPlayers);
  const [selectedPlayers, setSelectedPlayers] = useState([]);
  const [alertShown, setAlertShown] = useState(() => {
  const savedTeam = localStorage.getItem("finalTeam");
  if (savedTeam) {
    const parsed = JSON.parse(savedTeam);
    return parsed.length === 11; // If team is full, alert is "already shown"
  }
  return false;
});
  const [count, setcount] = useState(() => {
  const savedTeam = localStorage.getItem("finalTeam");
  if (savedTeam) {
    const parsed = JSON.parse(savedTeam);
    return parsed.length;
  }
  return 0;
});
  const total = selectedPlayers.reduce((sum, player) => sum + player.Salary, 0);

  // 1. Initialize state directly from localStorage to prevent the "default value" overwrite
const [money, setmoney] = useState(() => {
  const savedMoney = localStorage.getItem("newmoney");
  return savedMoney ? JSON.parse(savedMoney) : 1000;
});

const [typingmoney, settypingmoney] = useState(money);//Start with the same value as money, but allow it to be edited independently until "Set Money" is clicked

//  the useEffect to sync money with typingmoney whenever money changes (like after setting a new budget)
// this ensures that the button set money is working as intended( the money is updated to the new vallue iff set money button is clicked)
useEffect(() => {
  settypingmoney(money);
}, [money]);

  useEffect(() => {
    localStorage.setItem("newmoney", JSON.stringify(money));
},[money]);
useEffect(() => {
  const savedTeam = localStorage.getItem("finalTeam");
  if (savedTeam)
  {
    const parsed = JSON.parse(savedTeam);
    setSelectedPlayers(parsed);
    setcount(parsed.length); // ✅ restore count too

    // if(count === 11) //this is also asynnchronus update issue because count is not updated immediately after setcount, so we should not rely on it here. Instead, we can check the length of the parsed team directly.
     if(parsed.length === 11)
    {
    setAlertShown(true);
    }
  }
}, []);

useEffect(()=>{
  const RemainingPlayers = localStorage.getItem("Remaining Players");
  if(RemainingPlayers){
    const parsedRemaining=JSON.parse(RemainingPlayers);
    setAvailablePlayers(parsedRemaining);
  }
},[]);

  const moneyleft=money-total;
  
  // The function that does the actual moving
  function handleSelectPlayer(playerToMove) {
    if(count<11 && playerToMove.Salary<=moneyleft)
    {// 1. Remove from available
    setAvailablePlayers(availablePlayers.filter(p => p.Playername !== playerToMove.Playername));
    
    // 2. Add to selected
    setSelectedPlayers([...selectedPlayers, playerToMove]);
    
    setcount(count+1);
    }
    if(playerToMove.Salary>moneyleft){alert("Remaining Money is insufficent,Player cannot be selected");}
  }

  function handleAvailablePlayers(playerToMove)
  {
    setAvailablePlayers([...availablePlayers,playerToMove]);
    setSelectedPlayers(selectedPlayers.filter(p=>p.Playername!=playerToMove.Playername));
    setcount(count-1);
  }

  function handleMoney(e){
    if (typingmoney < total) {
      alert("New budget is less than what you already spent!");
      return;
    }
    setmoney(typingmoney);
    // alert(`Budget updated to ${money}`);This will show the old value of money because state updates are asynchronous. We should use the new value directly in the alert.
    alert(`Budget updated to ${typingmoney}`);
  }

  useEffect(() => {
  // Only alert if count is 11 AND we haven't shown the alert yet
  if (count === 11 && !alertShown) {
    // Use setTimeout to push the alert to the back of the line,
      // giving the browser a split second to paint the new UI first.
    setTimeout(() => {
      alert("Number of members in the team completed");
      setAlertShown(true); // Mark as shown
    }, 10);// 10 milliseconds is plenty of time
  } 
  // Reset the flag if the user removes a player (count goes below 11)
  else if (count < 11) {
    setAlertShown(false);
  }
}, [count, alertShown]);

  const [view, setView] = useState("login"); // "signup" or "login"

  const HandleView = () => {
    setView(view === "signup" ? "login" : "signup");
  }

  const[isLoggedIn,setisLoggedIn]=useState(()=>
  {
    const savedUser = localStorage.getItem("loggedIn");
    return savedUser ? JSON.parse(savedUser) : false;
  });

  useEffect(()=>
  {
    localStorage.setItem("loggedIn", JSON.stringify(isLoggedIn));
  }, [isLoggedIn]);

  const HandleLoginState = ()=>{
    setisLoggedIn(!isLoggedIn);
  }

  const style={marginBottom:'20px', padding:'10px 20px', borderRadius:'5px', border:'none', cursor:'pointer', backgroundColor:'rgba(0, 0, 0, 0.7)', color:'white'};
  return (
    <>
    
    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
    <img src={CricketImage} alt="Cricket Logo" style={{width:'500px',height:'100px',alignItems:'center'}}/>
    <h1 style={{fontFamily:'monospace',fontSize:'70px'}}>Welcome to <span style={{color:'blue',fontFamily:'cursive'}}>Playyy!</span></h1>
    </div>
    {!isLoggedIn&& <div className='Entry'>
    <button onClick={HandleView} style={{...style,marginRight:'5px',marginLeft:'200px'}}>
      {view === "signup" ? "Already have an account? Log In" : "Don't have an account? Sign Up"}
    </button>

    {view=="login"&& <Login isLoggedIn={isLoggedIn} setisLoggedIn={setisLoggedIn}/>}
    {view=="signup"&& <SignUp />}

    </div>}
    
    {isLoggedIn && 
    <div>
    <button onClick={HandleLoginState} style={{...style,marginLeft:'1400px',marginBottom:'10px'}}>
      Log Out
    </button>
    <div style={{display:'block',marginBottom:'20px'}}>
    <label htmlFor='Moneyinput' style={{ color: 'blue', fontWeight: 'bold' ,padding:'8px 10px'}}>Maximum Amount</label> (in units)
      {/* <input type='number' value={money} onChange={handleMoney} placeholder='Enter your total budget' id='Moneyinput'/> */}
        <input 
          type='number' 
          value={typingmoney} // Bind to the temporary state
          onChange={(e) => settypingmoney(Number(e.target.value))} 
          placeholder='Enter budget' 
          id='Moneyinput'
          style={{marginRight:'0px', padding:'5px', border:'1px solid gray' ,height:'25px', width:'150px'}}
        />
      <button onClick={handleMoney} style={{color:'white', backgroundColor:'blue', border:'none', padding:'10px 20px', cursor:'pointer'}}>Set Money</button>
      </div>
      <div>
        <h2 style={{ display: 'flex', width: '100%', textAlign: 'center', justifyContent: 'space-between' }}><div> Money Spent (1 unit=10,000 Rupees): {total} </div>
        <div> Players Selected: {count} </div>
        <div> Remaining Budget: {moneyleft} </div>
        </h2>
      </div>
      <Display 
        available={availablePlayers} 
        selected={selectedPlayers} 
        onAvailable={handleSelectPlayer}
        onSelect={handleAvailablePlayers}
        count={count}
        moneyleft={moneyleft}
      />
      
    </div>  
    }
    </>
  );
}
export default App;

