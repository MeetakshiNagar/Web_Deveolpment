import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Login = ({ setIsLoggedIn }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email === "test@gmail.com" && password === "react123") { setIsLoggedIn(true); navigate("/home");} 
    else { setError("Invalid username or password"); } 
};

  return (
    <div className="flex justify-center mt-[50px]">
      <form onSubmit={handleSubmit} className="flex flex-col gap-[10px] w-[300px]">
        <h2>Login</h2>
        {error && <p className="text-red-600">{error}</p>}
        <input type="email" placeholder="Email" onChange={(e) => setEmail(e.target.value)} required/>
        <input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} required />
        <button type="submit">Login</button>
      </form>
    </div>
  );
};


export default Login;