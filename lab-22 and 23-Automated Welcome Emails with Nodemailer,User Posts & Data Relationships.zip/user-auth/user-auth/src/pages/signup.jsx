import { useState } from "react";
import { useNavigate } from "react-router-dom";

function SignUp(){
    const[form,setForm]=useState({
        "name": "",
        "email": "",
        "password": "",
    });
const navigate = useNavigate();
const handleChange=(e)=>{
    setForm({ ...form, [e.target.name]: e.target.value });
  };
const handleSubmit = (e) => {
    e.preventDefault();
    alert("Account created successfully!");
    navigate("/login");
  };
  return(
    <div className="display: flex justify-center mt-[60px]">
        <form onSubmit={handleSubmit} className="flex flex-col gap-[10px] w-[200px]">
            <h3>SignUp</h3>
            <input name="name" placeholder="Full Name" onChange={handleChange} required></input>
            <input email="email" type="email" placeholder="Email" onChange={handleChange} required></input>
            <input name="password" type="password" placeholder="Password" onChange={handleChange} required></input>
            <button type="submit">SignUp</button>
        </form>
    </div>
  )
}

export default SignUp;