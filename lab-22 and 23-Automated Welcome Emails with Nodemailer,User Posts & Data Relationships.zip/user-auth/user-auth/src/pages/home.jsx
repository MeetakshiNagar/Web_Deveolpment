import { useNavigate } from "react-router-dom";

const Home = ({ setIsLoggedIn }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    setIsLoggedIn(false);
    navigate("/login");
  };

  return (
    <div>
      <h1>Welcome back, User!</h1>
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default Home;