import { Link, useNavigate } from "react-router-dom";

const Navbar = ({ isLoggedIn, setIsLoggedIn }) => {
  const navigate = useNavigate();
  const handleLogout = () => { setIsLoggedIn(false); navigate("/login");};

  return (
    <nav className="flex justify-between p-[15px] bg-blue-800 text-white">
      <h2>AuthApp</h2>
      <div>
        {isLoggedIn ? (
          <>
            <Link to="/home" >Home</Link>
            <button onClick={handleLogout}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login" className="mx-[10px] text-white no-underline">Login</Link>
            <Link to="/signup" className="px-[10px] py-[5px] cursor-pointer">Signup</Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;