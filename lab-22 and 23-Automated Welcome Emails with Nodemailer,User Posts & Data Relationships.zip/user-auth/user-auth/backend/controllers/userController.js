const User = require("../models/User");
const sendWelcomeEmail = require("../utils/mailer");

exports.getUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password");

    if (!user) {
      return res.status(404).json({
        message: "User not found",
      });
    }

    try {
      await sendWelcomeEmail(email, name);
        console.log("Email sent");
    } catch (err) {
        console.log("Email failed:", err.message);
  }

    res.status(200).json({
      message: "User profile fetched successfully",
      user,
    });
  } catch (error) {
    res.status(500).json({
      message: "Server Error",
      error: error.message,
    });
  }
};