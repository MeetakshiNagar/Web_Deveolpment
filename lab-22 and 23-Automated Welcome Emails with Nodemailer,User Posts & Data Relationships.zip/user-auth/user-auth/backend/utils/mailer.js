const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const sendWelcomeEmail = async (userEmail, userName) => {
  const mailOptions = {
    from: `"Your App" <${process.env.EMAIL_USER}>`,
    to: userEmail,
    subject: "Welcome 🎉",
    html: `
      <h2>Welcome, ${userName}!</h2>
      <p>Thanks for joining our platform 🚀</p>
    `,
  };

  return transporter.sendMail(mailOptions);
};

module.exports = sendWelcomeEmail;